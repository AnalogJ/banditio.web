These protocol descriptors are copies of the following files:

 - [src/third_party/WebKit/Source/core/inspector/browser_protocol.json](https://chromium.googlesource.com/chromium/src/+/master/third_party/WebKit/Source/core/inspector/browser_protocol.json)
 - [src/third_party/WebKit/Source/platform/v8_inspector/js_protocol.json](https://chromium.googlesource.com/chromium/src/+/master/third_party/WebKit/Source/platform/v8_inspector/js_protocol.json)

**Important:** These files are **not** rolled automatically and should be updated manually from time to time.

Protocol descriptors are needed for the DevTools [hosted mode](https://docs.google.com/document/d/1WNF-KqRSzPLUUfZqQG5AFeU_Ll8TfWYcJasa_XGf7ro/view#heading=h.9t7np5fa400) only.
